package com.example.finalyearproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class Events extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewpager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);


        tabLayout = findViewById(R.id.tablayout);
        viewpager = findViewById(R.id.viewpager);

        tabLayout.setupWithViewPager(viewpager);

        Adapter adapter = new Adapter(getSupportFragmentManager(),FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adapter.addFragment(new Fragment_events(),"Events");
        adapter.addFragment(new fragment_news(),"news");
        viewpager.setAdapter(adapter);


    }
}