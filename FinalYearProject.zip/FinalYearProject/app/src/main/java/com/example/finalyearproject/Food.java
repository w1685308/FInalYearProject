package com.example.finalyearproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class Food extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewpager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        tabLayout = findViewById(R.id.tablayout2);
        viewpager = findViewById(R.id.viewpager2);

        tabLayout.setupWithViewPager(viewpager);

        Adapter adapter = new Adapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adapter.addFragment(new Fragment_Marylebone(),"Marylebone");
        adapter.addFragment(new Fragment_Cavendish(),"Cavendish");
        adapter.addFragment(new Fragment_Harrow(),"Harrow");
        viewpager.setAdapter(adapter);
    }
}