package com.example.finalyearproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Fragment_Cavendish extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment__cavendish, container, false);

        String [] FoodList = {"ICCO" ,"Passynk Avenue", "Leon", "Nandos", "KFC", "Wok to Walk", "Goodge Street Food", "Vapiano", "Efes", "Sababa Station", "Domino's Pizza"};

        ListView listView = (ListView) view.findViewById(R.id.cavendish_food);

        ArrayAdapter<String> listViewAdapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                FoodList
        );

        listView.setAdapter(listViewAdapter);
        return view;
    }
}