package com.example.FinalYearProjectApp.Adapter;

import android.view.View;

public interface OnItemClick {
    public void onItemCLick(String uid, View view);
}
