package com.example.FinalYearProjectApp.Fragments;

public interface APIService {
    /*@Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAAHtZjkvQ:APA91bF75mPEzH-h-R4eQZPusq3K31UKf0Z3axUGTCY466rbbU_BQLH5PPi3vlFpEcSG7FkJdQ0ULpu_iHM5R6V1jTo-xxqqTvOOBO2hQ3pO7z-GjQSnEA0bkvAAO5cs1wVwcxJVtVXc"
            }
    )

    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);*/
}
