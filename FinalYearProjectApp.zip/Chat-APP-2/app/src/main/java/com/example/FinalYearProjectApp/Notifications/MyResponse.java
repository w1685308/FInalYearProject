package com.example.FinalYearProjectApp.Notifications;

public class MyResponse {

    public int success;
}
